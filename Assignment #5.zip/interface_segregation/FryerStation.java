package interface_segregation;

public class FryerStation implements FryerMeal{
    public Meal fryMeal() {
        return new Meal("Stake");
    }
}