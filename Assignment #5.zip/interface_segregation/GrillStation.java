package interface_segregation;

public class GrillStation implements GrillMeal {
    public Meal grillMeal() {
        return new Meal("Barbeque");
    }
}
