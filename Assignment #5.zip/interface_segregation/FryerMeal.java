package interface_segregation;

public interface FryerMeal {
    //seperate interface for fr meal
        Meal fryMeal();
    }

