package interface_segregation;

public interface GrillMeal {
    //individual interface for grill
    Meal grillMeal();
}