package dependancy_inversion;

public class DatabaseHandler implements Connection{
    private Connectable db;
    public boolean connected;

    public DatabaseHandler(Connectable database){
        this.db = database;
        this.connected = false;
    }

    public boolean isConnected(){
        return this.connected;
    }

    //fo checking connection
    public void press(){
        boolean check = isConnected();
        if(check){
            this.db.disconnect();
            this.connected = false;
        } else{
            this.db.connect();
            this.connected = true;
        }}}
