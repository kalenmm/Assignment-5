package dependancy_inversion;

public interface Connection {
    //fo impl. in database_handler
    boolean isConnected();
    void press();
}
