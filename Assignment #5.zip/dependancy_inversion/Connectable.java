package dependancy_inversion;

public interface Connectable {
        //fo implement. in Oracle & MysqlD.
        void connect();
        void disconnect();
}
