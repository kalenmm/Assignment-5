package liskov_substitution;

public interface Dbase {
    String addToDatabase();
}
