package liskov_substitution;

public interface Cash {
    String receiveCashback() throws Exception;
}
