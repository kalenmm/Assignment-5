package liskov_substitution;

public class IndividualCustomer implements Dbase, Cash {
    String name;
    final String customerType = "Individual Customer";

    public IndividualCustomer(String name) {
        this.name = name;
    }

    public String addToDatabase() {
        return (customerType + " " + this.name + " added to database");
    }

    public String receiveCashback() {
        return (customerType + " " + this.name + " received cashback");
    }
}
