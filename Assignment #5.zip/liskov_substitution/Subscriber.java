package liskov_substitution;


public class Subscriber implements Dbase{
    String name;

    final String customerType = "New subscriber";
    public Subscriber(String name){
        this.name = name;
    }

    public String addToDatabase() {
        return (customerType + " " + this.name +  " succesfully added to database");
    }
}
